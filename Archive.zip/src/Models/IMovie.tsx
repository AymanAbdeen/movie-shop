export interface IMovie {
    id: number;
    name: string;
    price: number;
    imagUrl: string;
    year: number;
    productCategory: {
        categoryId: number;
    }
}

export interface Icategories {
    id: number;
    name: string;
}




